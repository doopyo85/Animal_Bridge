import pygame
import json
import os
from typing import List, Tuple, Optional
import random

class TileMap:
    def __init__(self, tilemap_path: str, tile_size: int = 24, spacing: int = 1):
        self.tile_size = tile_size
        self.spacing = spacing
        
        try:
            self.tilemap_image = pygame.image.load(tilemap_path).convert_alpha()
        except pygame.error:
            print(f"타일맵 이미지를 불러올 수 없습니다: {tilemap_path}")
            self.tilemap_image = None
            
        self.tiles = {}
        self._extract_tiles()
    
    def _extract_tiles(self):
        if not self.tilemap_image:
            return
            
        tilemap_width = self.tilemap_image.get_width()
        tilemap_height = self.tilemap_image.get_height()
        
        tiles_per_row = (tilemap_width + self.spacing) // (self.tile_size + self.spacing)
        tiles_per_col = (tilemap_height + self.spacing) // (self.tile_size + self.spacing)
        
        tile_id = 0
        for row in range(tiles_per_col):
            for col in range(tiles_per_row):
                x = col * (self.tile_size + self.spacing)
                y = row * (self.tile_size + self.spacing)
                
                tile_rect = pygame.Rect(x, y, self.tile_size, self.tile_size)
                tile_surface = pygame.Surface((self.tile_size, self.tile_size), pygame.SRCALPHA)
                tile_surface.blit(self.tilemap_image, (0, 0), tile_rect)
                
                self.tiles[tile_id] = tile_surface
                tile_id += 1
    
    def get_tile(self, tile_id: int) -> Optional[pygame.Surface]:
        return self.tiles.get(tile_id)
    
    def render_tile(self, screen: pygame.Surface, tile_id: int, x: int, y: int, 
                width: int = None, height: int = None):
        tile = self.get_tile(tile_id)
        if tile:
            if width and height:
                tile = pygame.transform.smoothscale(tile, (width, height))
            screen.blit(tile, (x, y))
    
    def render_tiled_rect(self, screen: pygame.Surface, tile_id: int, 
                         rect: pygame.Rect, scale: float = 1.0):
        tile = self.get_tile(tile_id)
        if not tile:
            return
            
        scaled_tile_size = int(self.tile_size * scale)
        scaled_tile = pygame.transform.scale(tile, (scaled_tile_size, scaled_tile_size))
        
        for x in range(rect.left, rect.right, scaled_tile_size):
            for y in range(rect.top, rect.bottom, scaled_tile_size):
                clip_width = min(scaled_tile_size, rect.right - x)
                clip_height = min(scaled_tile_size, rect.bottom - y)
                
                if clip_width < scaled_tile_size or clip_height < scaled_tile_size:
                    clipped_tile = scaled_tile.subsurface(0, 0, clip_width, clip_height)
                    screen.blit(clipped_tile, (x, y))
                else:
                    screen.blit(scaled_tile, (x, y))


class BackgroundRenderer:
    def __init__(self, background_tilemap_path: str, tile_size: int = 24, spacing: int = 1):
        self.tilemap = TileMap(background_tilemap_path, tile_size, spacing)

    def generate_background_pattern(self, screen: pygame.Surface, sky_id: int = 0, cloud_ids: List[int] = [1]) -> List[List[int]]:
        screen_width = screen.get_width()
        screen_height = screen.get_height()
        tile_size = self.tilemap.tile_size

        cols = screen_width // tile_size + 1
        rows = screen_height // tile_size + 1

        pattern = []
        for row in range(rows):
            current_row = []
            for col in range(cols):
                if row % 4 == 1 and cloud_ids and random.random() < 0.4:
                    tile_id = random.choice(cloud_ids)
                else:
                    tile_id = sky_id
                current_row.append(tile_id)
            pattern.append(current_row)
        return pattern

    def generate_fixed_background_pattern(self, rows=4, cols=8, sky_id=0, cloud_ids=[1]) -> List[List[int]]:
        """8x4 고정 배경 패턴 생성"""
        pattern = []
        for row in range(rows):
            current_row = []
            for col in range(cols):
                if row % 2 == 1 and cloud_ids and random.random() < 0.4:
                    tile_id = random.choice(cloud_ids)
                else:
                    tile_id = sky_id
                current_row.append(tile_id)
            pattern.append(current_row)
        return pattern

    def render_background(self, screen: pygame.Surface, tile_pattern: List[List[int]] = None):
        """배경을 단순 하늘색으로 채움"""
        screen.fill((135, 206, 235))  # Sky blue


class TerrainRenderer:
    def __init__(self, terrain_tilemap_path: str, tile_size: int = 24, spacing: int = 0):
        self.tilemap = TileMap(terrain_tilemap_path, tile_size, spacing)
        self.TILE_TYPES = {
            'grass_top': 0,        # (row=0, col=0)
            'grass_middle': 72,    # (row=3, col=0)
            'stone_top': 2,        # (row=0, col=2) ← 바위 위면
            'stone_middle': 51,    # (row=2, col=3) ← 절벽 안쪽 흙
            'dirt_top': 26,        # (row=1, col=2) ← 눈 쌓인 흙 (원래대로 유지)
            'dirt_middle': 55,     # (row=2, col=7)
            'platform': 28,        # (row=1, col=4) ← 나무 판자
            'bridge': 56           # (row=2, col=8) ← 나무 다리
        }

    def render_terrain(self, screen: pygame.Surface, terrain_rects: List[pygame.Rect]):
        for i, rect in enumerate(terrain_rects):
            if self.tilemap.tilemap_image is None:
                if i == 0 or i == 1:
                    pygame.draw.rect(screen, (139, 69, 19), rect)
                else:
                    pygame.draw.rect(screen, (160, 82, 45), rect)
                pygame.draw.rect(screen, (101, 67, 33), rect, 2)
            else:
                if i == 0 or i == 1:
                    self.render_terrain_block(screen, rect, 'grass_top', 2.0)
                else:
                    self.render_bridge(screen, rect, 2.0)

    def render_terrain_block(self, screen: pygame.Surface, rect: pygame.Rect, tile_type: str = 'grass_top', scale: float = 1.0):
        tile_id = self.TILE_TYPES.get(tile_type, 0)
        self.tilemap.render_tiled_rect(screen, tile_id, rect, scale)

    def render_platform(self, screen: pygame.Surface, rect: pygame.Rect, scale: float = 1.0):
        self.render_terrain_block(screen, rect, 'platform', scale)

    def render_bridge(self, screen: pygame.Surface, rect: pygame.Rect, scale: float = 1.0):
        self.render_terrain_block(screen, rect, 'bridge', scale)


class TileMapManager:
    def __init__(self, assets_path: str = None):
        if assets_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            assets_path = os.path.join(current_dir, "assets", "Tilemap")
        
        background_path = os.path.join(assets_path, "tilemap-backgrounds24.png")
        terrain_path = os.path.join(assets_path, "tilemap24.png")
        
        print(f"Looking for background file at: {background_path}")
        print(f"Looking for terrain file at: {terrain_path}")
        
        self.background_renderer = BackgroundRenderer(background_path, 24, 0)
        self.terrain_renderer = TerrainRenderer(terrain_path, 24, 0)

        self.sky_id = 0
        self.cloud_ids = [1]

        # 화면 크기 기반으로 나중에 설정
        self.default_background_pattern = None

        if self.default_background_pattern is None:
            self.default_background_pattern = self.background_renderer.generate_fixed_background_pattern()

    def render_game_background(self, screen: pygame.Surface):
        if self.background_renderer.tilemap.tilemap_image is None:
            screen.fill((135, 206, 235))
        else:
            if self.default_background_pattern is None:
                self.default_background_pattern = self.background_renderer.generate_background_pattern(
                    screen, self.sky_id, self.cloud_ids
                )
            self.background_renderer.render_background(screen, self.default_background_pattern)

    def render_terrain(self, screen: pygame.Surface, terrain_rects: List[pygame.Rect]):
        self.terrain_renderer.render_terrain(screen, terrain_rects)
