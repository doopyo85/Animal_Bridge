import pygame
import sys
import pymunk
import pymunk.pygame_util
import math
import json
import os
from settings import *
from render_manager import RenderManager
from audio_manager import audio_manager

# ======================================================================================
# 크기 및 위치 조절을 위한 헬퍼 함수
# ======================================================================================
BASE_WIDTH, BASE_HEIGHT = 1280, 720

def scale_x(value):
    return int(value * (WIDTH / BASE_WIDTH))

def scale_y(value):
    return int(value * (HEIGHT / BASE_HEIGHT))

def scale_font(size):
    avg_scale = (WIDTH / BASE_WIDTH + HEIGHT / BASE_HEIGHT) / 2
    return int(size * avg_scale)

# ======================================================================================
# 랭킹 데이터 관리
# ======================================================================================
RANKING_FILE = 'ranking.json'

def load_rankings():
    try:
        with open(RANKING_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        # 동적으로 스테이지 수 결정
        num_stages = len(STAGE_DATA)
        return {str(i): [] for i in range(1, num_stages + 1)}

def save_rankings(data):
    with open(RANKING_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def add_ranking_entry(stage, name, blocks, time_seconds, eaten_count):
    rankings = load_rankings()
    stage_key = str(stage)
    new_entry = {"name": name, "blocks": blocks, "time": time_seconds, "eaten": eaten_count}
    if stage_key not in rankings:
        rankings[stage_key] = []
    rankings[stage_key].append(new_entry)
    rankings[stage_key].sort(key=lambda x: x['time'])
    rankings[stage_key] = rankings[stage_key][:10]
    save_rankings(rankings)

# ======================================================================================
# 게임 오브젝트 클래스들
# ======================================================================================
class Player:
    def __init__(self, space, pos):
        self.body = pymunk.Body(10, float('inf'), body_type=pymunk.Body.DYNAMIC) 
        self.body.position = pos
        self.custom_gravity_force = scale_y(18000)
        self.shape = pymunk.Circle(self.body, scale_x(20))
        self.shape.elasticity = 0.1
        self.shape.friction = 0.7 
        self.shape.color = RED
        player_mask = TERRAIN_CATEGORY | CEILING_CATEGORY | ANIMAL_CATEGORY
        self.shape.filter = pymunk.ShapeFilter(categories=PLAYER_CATEGORY, mask=player_mask)
        self.shape.collision_type = PLAYER_COLLISION_TYPE
        space.add(self.body, self.shape)
        self.is_grounded = False

    def update(self, space):
        self.body.apply_force_at_local_point((0, self.custom_gravity_force))
        self.is_grounded = False
        def check_grounding(arbiter):
            if abs(arbiter.normal.y) > 0.7: self.is_grounded = True
        self.body.each_arbiter(check_grounding)

    def set_horizontal_velocity(self, new_vx):
        self.body.velocity = (new_vx, self.body.velocity.y)

    def jump(self):
        if self.is_grounded:
            jump_impulse = scale_y(-4000)
            self.body.velocity = (self.body.velocity.x, 0)
            self.body.apply_impulse_at_local_point((0, jump_impulse))
            audio_manager.play_sound('jump')
    
    def draw(self, screen):
        """플레이어 렌더링"""
        # 간단한 원형 플레이어
        pos = (int(self.body.position.x), int(self.body.position.y))
        radius = scale_x(20)
        
        # 그림자 (더 진하게)
        shadow_pos = (pos[0] + 3, pos[1] + 3)
        pygame.draw.circle(screen, (80, 0, 0), shadow_pos, radius)
        
        # 메인 플레이어 원 (더 밝게)
        pygame.draw.circle(screen, (255, 50, 50), pos, radius)
        
        # 테두리 (더 두껍게)
        pygame.draw.circle(screen, (200, 0, 0), pos, radius, 4)
        
        # 눈 (간단한 얼굴)
        eye_offset = scale_x(7)
        eye_radius = scale_x(4)
        left_eye = (pos[0] - eye_offset, pos[1] - scale_y(6))
        right_eye = (pos[0] + eye_offset, pos[1] - scale_y(6))
        pygame.draw.circle(screen, WHITE, left_eye, eye_radius)
        pygame.draw.circle(screen, WHITE, right_eye, eye_radius)
        pygame.draw.circle(screen, BLACK, left_eye, eye_radius - 2)
        pygame.draw.circle(screen, BLACK, right_eye, eye_radius - 2)
        
        # 입 (웃는 모습)
        mouth_center = (pos[0], pos[1] + scale_y(8))
        mouth_radius = scale_x(8)
        start_angle = 0
        end_angle = 3.14159  # 180도
        pygame.draw.arc(screen, BLACK, 
                       (mouth_center[0] - mouth_radius//2, mouth_center[1] - mouth_radius//2, 
                        mouth_radius, mouth_radius), 
                       start_angle, end_angle, 2)

class AnimalBlock:
    def __init__(self, space, pos, animal_name, block_scale, angle_degrees=0, is_ui_element=False):
        self.name, self.is_ui_element, self.head_part_offsets = animal_name, is_ui_element, []
        self.image = None

        hash_value = hash(animal_name)
        r, g, b = (hash_value & 0xFF0000) >> 16, (hash_value & 0x00FF00) >> 8, hash_value & 0x0000FF
        self.icon_color, self.body_color, self.face_color, self.eye_color = (r, g, b), (65, 105, 225, 255), (255, 165, 0, 255), BLACK

        block_shape_str = ANIMAL_DATA.get(self.name, [])
        try:
            # 현재 스크립트 파일 위치를 기준으로 img 경로 설정
            current_dir = os.path.dirname(os.path.abspath(__file__))
            image_path = os.path.join(current_dir, 'assets', 'img', f'{self.name}.png')
            self.image = pygame.image.load(image_path).convert_alpha()
        except FileNotFoundError:
            self.image = None

        if is_ui_element:
            self.rect = pygame.Rect(pos[0] - scale_x(30), pos[1] - scale_y(30), scale_x(60), scale_y(60))
            if self.image:
                self.image = pygame.transform.scale(self.image, (scale_x(60), scale_y(60)))
            return

        self.body, self.body.position = pymunk.Body(body_type=pymunk.Body.DYNAMIC), pos
        self.body.angle = math.radians(angle_degrees)
        if not block_shape_str: return
        
        height = len(block_shape_str)
        width = len(block_shape_str[0]) if height > 0 else 0
        scale, self.shapes, head_part_local_coords = block_scale, [], []

        if self.image:
            img_width = int(width * scale)
            img_height = int(height * scale)
            self.image = pygame.transform.scale(self.image, (img_width, img_height))
        
        for r_index, row in enumerate(block_shape_str):
            for c_index, char in enumerate(row):
                if char in ('1', '2'):
                    x_offset, y_offset = (c_index - width / 2 + 0.5) * scale, (r_index - height / 2 + 0.5) * scale
                    if char == '2': head_part_local_coords.append((x_offset, y_offset))
                    half = scale / 2
                    verts = [(-half + x_offset, -half + y_offset), ( half + x_offset, -half + y_offset), ( half + x_offset,  half + y_offset), (-half + x_offset,  half + y_offset)]
                    square_shape = pymunk.Poly(self.body, verts)
                    square_shape.elasticity, square_shape.friction = 0.2, 1.0
                    animal_mask = PLAYER_CATEGORY | ANIMAL_CATEGORY | TERRAIN_CATEGORY
                    square_shape.filter = pymunk.ShapeFilter(categories=ANIMAL_CATEGORY, mask=animal_mask)

                    if self.image:
                        square_shape.color = (0, 0, 0, 0)
                    elif char == '2' and self.name in CARNIVORES:
                        square_shape.color, square_shape.collision_type = self.face_color, CARNIVORE_HEAD_COLLISION_TYPE
                    else:
                        square_shape.color = self.body_color
                    self.shapes.append(square_shape)

        if self.name in CARNIVORES and head_part_local_coords:
            self.head_part_offsets = [pymunk.Vec2d(x, y) for x, y in head_part_local_coords]

        for s in self.shapes: s.mass = 100
        space.add(self.body, *self.shapes)

    def draw(self, screen):
        if self.image:
            angle_degrees = math.degrees(self.body.angle) * -1
            rotated_image = pygame.transform.rotate(self.image, angle_degrees)
            rect = rotated_image.get_rect(center=self.body.position)
            screen.blit(rotated_image, rect.topleft)
        else:
            self.draw_details(screen)

    def draw_details(self, screen):
        if self.is_ui_element or self.name not in CARNIVORES or not self.head_part_offsets: return
        head_world_pos = self.body.local_to_world(self.head_part_offsets[0])
        eye_radius = scale_x(4)
        left_eye_pos, right_eye_pos = (head_world_pos.x - scale_x(8), head_world_pos.y - scale_y(5)), (head_world_pos.x + scale_x(8), head_world_pos.y - scale_y(5))
        pygame.draw.circle(screen, self.eye_color, left_eye_pos, eye_radius)
        pygame.draw.circle(screen, self.eye_color, right_eye_pos, eye_radius)

class Flag:
    def __init__(self, pos):
        pole_height, pole_width = scale_y(60), scale_x(5)
        self.pole_rect = pygame.Rect(pos[0], pos[1] - pole_height, pole_width, pole_height)
        self.cloth_points = [(pos[0] + pole_width, pos[1] - pole_height), (pos[0] + pole_width, pos[1] - pole_height + scale_y(25)), (pos[0] + pole_width + scale_x(40), pos[1] - pole_height + scale_y(12.5))]
        self.pole_color, self.cloth_color = (192, 192, 192), (220, 20, 60)

    def draw(self, screen):
        pygame.draw.rect(screen, self.pole_color, self.pole_rect)
        pygame.draw.polygon(screen, self.cloth_color, self.cloth_points)

# ======================================================================================
# 물리 시스템 관련 함수들
# ======================================================================================
def create_static_body(space, pos, size, category, mask):
    body = pymunk.Body(body_type=pymunk.Body.STATIC)
    body.position = pos
    shape = pymunk.Poly.create_box(body, size)
    shape.elasticity, shape.friction = 0.4, 0.9
    # 물리 객체는 투명하게 설정 (타일맵으로 렌더링할 예정)
    shape.color = (0, 0, 0, 0)
    shape.filter = pymunk.ShapeFilter(categories=category, mask=mask)
    space.add(body, shape)
    return body, shape

def setup_level(space, terrain_specs):
    terrain_mask = PLAYER_CATEGORY | ANIMAL_CATEGORY
    terrain_bodies = []
    
    for spec in terrain_specs:
        pos_x, pos_y, size_w, size_h = spec
        center_pos = (scale_x(pos_x), scale_y(pos_y))
        size = (scale_x(size_w), scale_y(size_h))
        body, shape = create_static_body(space, center_pos, size, TERRAIN_CATEGORY, terrain_mask)
        terrain_bodies.append((body, shape))
    
    # 경계 설정
    create_static_body(space, (WIDTH / 2, scale_y(-10)), (WIDTH, scale_y(20)), CEILING_CATEGORY, PLAYER_CATEGORY)
    create_static_body(space, (scale_x(-10), HEIGHT / 2), (scale_x(20), HEIGHT), TERRAIN_CATEGORY, terrain_mask)
    create_static_body(space, (WIDTH + scale_x(10), HEIGHT / 2), (scale_x(20), HEIGHT), TERRAIN_CATEGORY, terrain_mask)
    create_static_body(space, (WIDTH / 2, HEIGHT + scale_y(10)), (WIDTH, scale_y(20)), TERRAIN_CATEGORY, terrain_mask)
    
    return terrain_bodies

def get_terrain_rects(terrain_specs):
    """지형 스펙에서 pygame.Rect 리스트 생성"""
    terrain_rects = []
    for spec in terrain_specs:
        pos_x, pos_y, size_w, size_h = spec
        center_x, center_y = scale_x(pos_x), scale_y(pos_y)
        width, height = scale_x(size_w), scale_y(size_h)
        rect = pygame.Rect(center_x - width//2, center_y - height//2, width, height)
        terrain_rects.append(rect)
    return terrain_rects

# ======================================================================================
# 게임 상태 관리
# ======================================================================================
class GameState:
    def __init__(self):
        self.current_state = "start_menu"
        self.player_name = ""
        self.selected_stage = 1
        self.sound_volume = 1.0
        self.current_res_index = 0
        
    def change_state(self, new_state, data=None):
        self.current_state = new_state
        if data:
            if "player_name" in data:
                self.player_name = data["player_name"]
            if "selected_stage" in data:
                self.selected_stage = data["selected_stage"]
            if "volume" in data:
                self.sound_volume = data["volume"]
            if "res_index" in data:
                self.current_res_index = data["res_index"]

# ======================================================================================
# 게임 플레이 핵심 로직
# ======================================================================================
def game_play_logic(screen, clock, stage_level, player_name_param, render_manager):
    """게임 플레이 핵심 로직 - 렌더링은 render_manager가 담당"""
    stage_data = STAGE_DATA.get(str(stage_level), STAGE_DATA["1"])
    available_animals, terrain_specs = stage_data["available_animals"], stage_data["terrain"]
    is_violent_stage = stage_data.get("violent_carnivores", False)
    
    # 물리 세계 초기화
    space = pymunk.Space()
    space.gravity = (0, scale_y(981))
    
    # 레벨 설정
    terrain_bodies = setup_level(space, terrain_specs)
    terrain_rects = get_terrain_rects(terrain_specs)
    
    # 게임 오브젝트 초기화
    player = Player(space, (scale_x(80), scale_y(280)))
    goal_flag = Flag((scale_x(1200), scale_y(300)))
    game_objects, to_be_eaten, dragging_animal = [], [], None
    blocks_used_count, eaten_blocks_count, start_time = 0, 0, pygame.time.get_ticks()
    player_is_dead = False
    
    # 폰트 설정
    fonts = {
        'small': pygame.font.SysFont("malgungothic", scale_font(10))
    }
    
    def player_hit_carnivore_head(arbiter, space, data):
        nonlocal player_is_dead
        player_is_dead = True
        return True
    
    if is_violent_stage:
        handler = space.add_collision_handler(PLAYER_COLLISION_TYPE, CARNIVORE_HEAD_COLLISION_TYPE)
        handler.begin = player_hit_carnivore_head
        
    # UI 동물들 초기화
    ui_animals = []
    block_scale = WIDTH / (BASE_WIDTH / 56.25)
    for i, name in enumerate(available_animals):
        row, col = i // 7, i % 7
        pos = (scale_x(140 + col * 160), scale_y(630 if row == 0 else 690))
        ui_animals.append(AnimalBlock(space, pos, name, block_scale, is_ui_element=True))
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if player_is_dead:
                return "game_over"

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_TAB:
                    audio_manager.play_sound('click')
                    return "stage_select"
                if event.key == pygame.K_SPACE: 
                    player.jump()
                if event.key == pygame.K_r and dragging_animal:
                    dragging_animal["angle_degrees"] = (dragging_animal["angle_degrees"] + 90) % 360

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for ui_animal in ui_animals:
                    if ui_animal.rect.collidepoint(event.pos) and not dragging_animal:
                        dragging_animal = {
                            "name": ui_animal.name,
                            "image": ui_animal.image,
                            "angle_degrees": 0
                        }
                        break
                        
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if dragging_animal:
                    mouse_pos = pygame.mouse.get_pos()
                    drop_zone = pygame.Rect(scale_x(300), scale_y(30), scale_x(680), scale_y(130))
                    if drop_zone.collidepoint(mouse_pos):
                        new_block = AnimalBlock(
                            space, 
                            mouse_pos, 
                            dragging_animal["name"], 
                            block_scale, 
                            angle_degrees=dragging_animal["angle_degrees"]
                        )
                        game_objects.append(new_block)
                        blocks_used_count += 1
                        audio_manager.play_sound('place')
                    dragging_animal = None

        if player_is_dead:
            return "game_over"
            
        # 플레이어 업데이트
        player.update(space)
        keys = pygame.key.get_pressed()
        target_vx, move_speed = 0, scale_x(250)
        if keys[pygame.K_a]: target_vx = -move_speed
        elif keys[pygame.K_d]: target_vx = move_speed
        player.set_horizontal_velocity(target_vx)
        
        # 육식동물의 포식 행동
        head_part_eating_range = scale_x(40)
        for carnivore in [obj for obj in game_objects if obj.name in CARNIVORES]:
            for prey in [obj for obj in game_objects if obj not in to_be_eaten and obj.name not in CARNIVORES and obj != carnivore]:
                for head_offset in carnivore.head_part_offsets:
                    if prey.shapes and min(s.point_query(carnivore.body.local_to_world(head_offset)).distance for s in prey.shapes) < head_part_eating_range:
                        to_be_eaten.append(prey)
                        break
                if prey in to_be_eaten:
                    break
        
        # 렌더링
        render_manager.render_background("tilemap")
        render_manager.render_terrain(terrain_rects)
        
        # 플레이어 그리기 (항상 다른 객체보다 위에 그리기)
        player.draw(screen)
        
        # 게임 오브젝트 그리기
        for animal in game_objects:
            animal.draw(screen)
        goal_flag.draw(screen)

        # UI 렌더링
        stats = {
            "사용한 블럭": f"{blocks_used_count}개",
            "먹힌 블럭": f"{eaten_blocks_count}개",
            "시간": f"{(pygame.time.get_ticks() - start_time) // 1000}초"
        }
        render_manager.render_game_ui(ui_animals, dragging_animal, stats, fonts)

        # 승리 조건 체크
        if player.body.position.x > scale_x(1180) and player.body.position.y < scale_y(300):
            clear_time_seconds = (pygame.time.get_ticks() - start_time) / 1000
            add_ranking_entry(stage_level, player_name_param, blocks_used_count, clear_time_seconds, eaten_blocks_count)
            return "stage_clear", {
                "stage": stage_level,
                "blocks": blocks_used_count,
                "eaten": eaten_blocks_count,
                "time": clear_time_seconds
            }
            
        # 물리 시뮬레이션
        substeps = 5
        dt = 1.0 / (FPS * substeps)
        for _ in range(substeps): 
            space.step(dt)
            
        # 먹힌 동물들 제거
        if to_be_eaten:
            eaten_blocks_count += len(to_be_eaten)
            for animal in to_be_eaten:
                if animal in game_objects:
                    space.remove(animal.body, *animal.shapes)
                    game_objects.remove(animal)
            to_be_eaten.clear()
        
        pygame.display.flip()
        clock.tick(FPS)

# ======================================================================================
# 메인 게임 클래스
# ======================================================================================
class Game:
    def __init__(self):
        pygame.init()
        
        # 화면 설정
        global WIDTH, HEIGHT
        WIDTH, HEIGHT = RESOLUTIONS[0]
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        pygame.display.set_caption("Animal Bridge")
        self.clock = pygame.time.Clock()
        
        # 매니저들 초기화
        self.render_manager = RenderManager(self.screen)
        self.game_state = GameState()
        
        # 오디오 설정
        audio_manager.set_sound_volume(self.game_state.sound_volume)
        
    def run(self):
        """메인 게임 루프"""
        while True:
            # 화면 크기 변경 처리
            for event in pygame.event.get(pygame.VIDEORESIZE):
                global WIDTH, HEIGHT
                WIDTH, HEIGHT = event.size
                self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
                self.render_manager.update_screen_size(WIDTH, HEIGHT)

            # 현재 상태에 따른 처리
            if self.game_state.current_state == "start_menu":
                result = self.handle_start_menu()
                if result:
                    self.game_state.change_state(result[0], {"player_name": result[1]})
            
            elif self.game_state.current_state == "main_menu":
                result = self.handle_main_menu()
                if result:
                    self.game_state.change_state(result[0])
            
            elif self.game_state.current_state == "stage_select":
                result = self.handle_stage_select()
                if result:
                    if result[0] == "game_play":
                        self.game_state.change_state(result[0], {"selected_stage": result[1]})
                    else:
                        self.game_state.change_state(result[0])
            
            elif self.game_state.current_state == "game_play":
                result = game_play_logic(
                    self.screen, self.clock, 
                    self.game_state.selected_stage, 
                    self.game_state.player_name,
                    self.render_manager
                )
                if isinstance(result, tuple):
                    # 게임 클리어
                    self.game_state.change_state("stage_select")
                else:
                    # 게임 오버 또는 다른 상태
                    self.game_state.change_state(result if result != "game_over" else "main_menu")
            
            elif self.game_state.current_state == "description":
                result = self.handle_description()
                if result:
                    self.game_state.change_state(result)
            
            elif self.game_state.current_state == "settings":
                result = self.handle_settings()
                if result:
                    self.game_state.change_state(result)
            
            elif self.game_state.current_state == "ranking":
                result = self.handle_ranking()
                if result:
                    self.game_state.change_state(result)
            
            else:
                print(f"알 수 없는 상태: {self.game_state.current_state}")
                self.game_state.change_state("main_menu")

    def handle_description(self):
        """게임 설명 화면 처리"""
        back_button_rect = pygame.Rect(scale_x(50), HEIGHT - scale_y(100), scale_x(150), scale_y(60))
        fonts = {
            'desc': pygame.font.SysFont("malgungothic", scale_font(25))
        }
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                    audio_manager.play_sound('click')
                    return "main_menu"
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if back_button_rect.collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return "main_menu"
            self.render_manager.render_description(back_button_rect, fonts)
            pygame.display.flip()
            self.clock.tick(FPS)
            
    def handle_settings(self):
        """설정 화면 처리"""
        back_button_rect = pygame.Rect(scale_x(50), HEIGHT - scale_y(100), scale_x(150), scale_y(60))
        fonts = {
            'settings': pygame.font.SysFont("malgungothic", scale_font(30))
        }
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                    audio_manager.play_sound('click')
                    return "main_menu"
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if back_button_rect.collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return "main_menu"
            self.render_manager.render_settings(back_button_rect, fonts)
            pygame.display.flip()
            self.clock.tick(FPS)

    def handle_ranking(self):
        """랭킹 화면 처리"""
        current_stage = 1
        num_stages = len(STAGE_DATA)
        
        fonts = {
            'title': pygame.font.SysFont("malgungothic", scale_font(50), bold=True),
            'rank': pygame.font.SysFont("malgungothic", scale_font(30)),
            'arrow': pygame.font.SysFont("malgungothic", scale_font(40), bold=True),
            'button': pygame.font.SysFont("malgungothic", scale_font(40))
        }
        
        # UI 렉트 설정
        ui_rects = {
            'back_button': pygame.Rect(scale_x(50), HEIGHT - scale_y(100), scale_x(150), scale_y(60)),
            'left_arrow': pygame.Rect(WIDTH // 2 - scale_x(300), scale_y(110), scale_x(50), scale_y(50)),
            'right_arrow': pygame.Rect(WIDTH // 2 + scale_x(250), scale_y(110), scale_x(50), scale_y(50))
        }
        
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                    audio_manager.play_sound('click')
                    return "main_menu"
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if ui_rects['back_button'].collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return "main_menu"
                    elif ui_rects['left_arrow'].collidepoint(event.pos):
                        if current_stage > 1:
                            current_stage -= 1
                            audio_manager.play_sound('click')
                    elif ui_rects['right_arrow'].collidepoint(event.pos):
                        if current_stage < num_stages:
                            current_stage += 1
                            audio_manager.play_sound('click')
            
            # 랭킹 데이터 로드
            rankings = load_rankings()
            stage_rankings = rankings.get(str(current_stage), [])
            
            self.render_manager.render_ranking_screen(
                current_stage, stage_rankings, fonts, ui_rects
            )
            pygame.display.flip()
            self.clock.tick(FPS)
            
    def handle_start_menu(self):
        """시작 메뉴 처리"""
        player_name, input_active = "", False
        input_box = pygame.Rect(WIDTH // 2 - scale_x(200), HEIGHT // 2, scale_x(400), scale_y(80))
        next_button_rect = pygame.Rect(WIDTH // 2 - scale_x(100), HEIGHT // 2 + scale_y(120), scale_x(200), scale_y(80))
        
        fonts = {
            'title': pygame.font.SysFont("malgungothic", scale_font(90), bold=True),
            'prompt': pygame.font.SysFont("malgungothic", scale_font(60)),
            'input': pygame.font.SysFont("malgungothic", scale_font(50)),
            'placeholder': pygame.font.SysFont("malgungothic", scale_font(20), italic=True),
            'button': pygame.font.SysFont("malgungothic", scale_font(60))
        }
        
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    input_active = input_box.collidepoint(event.pos)
                    if next_button_rect.collidepoint(event.pos) and player_name:
                        audio_manager.play_sound('click')
                        return "main_menu", player_name
                if event.type == pygame.KEYDOWN and input_active:
                    if event.key == pygame.K_RETURN and player_name:
                        audio_manager.play_sound('click')
                        return "main_menu", player_name
                    elif event.key == pygame.K_BACKSPACE:
                        player_name = player_name[:-1]
                    else:
                        player_name += event.unicode
            
            self.render_manager.render_start_menu(
                player_name, input_active, input_box, next_button_rect, fonts
            )
            pygame.display.flip()
            self.clock.tick(FPS)

    def handle_main_menu(self):
        """메인 메뉴 처리"""
        button_rects = {
            'start': pygame.Rect(WIDTH // 2 - scale_x(150), HEIGHT // 2, scale_x(300), scale_y(80)),
            'desc': pygame.Rect(WIDTH // 2 - scale_x(200), HEIGHT // 2 + scale_y(100), scale_x(180), scale_y(70)),
            'rank': pygame.Rect(WIDTH // 2 + scale_x(20), HEIGHT // 2 + scale_y(100), scale_x(180), scale_y(70)),
            'settings': pygame.Rect(scale_x(30), scale_y(30), scale_x(50), scale_y(50))
        }
        
        fonts = {
            'title': pygame.font.SysFont("malgungothic", scale_font(90), bold=True),
            'name': pygame.font.SysFont("malgungothic", scale_font(30)),
            'button': pygame.font.SysFont("malgungothic", scale_font(60))
        }
        
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if button_rects['start'].collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return ("stage_select", None)
                    elif button_rects['desc'].collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return ("description", None)
                    elif button_rects['rank'].collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return ("ranking", None)
                    elif button_rects['settings'].collidepoint(event.pos):
                        audio_manager.play_sound('click')
                        return ("settings", None)
                if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                    return ("start_menu", None)
            
            self.render_manager.render_main_menu(
                self.game_state.player_name, button_rects, fonts
            )
            pygame.display.flip()
            self.clock.tick(FPS)

    def handle_stage_select(self):
       """스테이지 선택 처리"""
       # 동적으로 스테이지 개수 결정
       num_stages = len(STAGE_DATA)
       stage_buttons = {}
       
       if num_stages <= 4:
           # 4개 이하: 기존 레이아웃 사용
           positions = [
               (scale_x(300), scale_y(350)),
               (scale_x(640), scale_y(350)), 
               (scale_x(980), scale_y(350)),
               (WIDTH // 2, scale_y(550))
           ]
           for i in range(num_stages):
               stage_buttons[i + 1] = {
                   "pos": positions[i],
                   "radius": scale_x(80),
                   "current_radius": scale_x(80)
               }
       else:
           # 5개 이상: 그리드 레이아웃
           cols = min(5, num_stages)  # 최대 5열
           rows = (num_stages + cols - 1) // cols  # 필요한 행 수
           
           start_x = WIDTH // 2 - (cols - 1) * scale_x(150) // 2
           start_y = scale_y(250)
           
           for i in range(num_stages):
               row = i // cols
               col = i % cols
               x = start_x + col * scale_x(150)
               y = start_y + row * scale_y(150)
               
               stage_buttons[i + 1] = {
                   "pos": (x, y),
                   "radius": scale_x(60),
                   "current_radius": scale_x(60)
               }
       
       fonts = {
           'title': pygame.font.SysFont("malgungothic", scale_font(80), bold=True),
           'stage': pygame.font.SysFont("malgungothic", scale_font(40), bold=True),
           'feature': pygame.font.SysFont("malgungothic", scale_font(25), bold=True),
           'popup_title': pygame.font.SysFont("malgungothic", scale_font(60), bold=True),
           'popup_info': pygame.font.SysFont("malgungothic", scale_font(50))
       }
       
       selected_stage = None
       
       while True:
           for event in pygame.event.get():
               if event.type == pygame.QUIT:
                   pygame.quit()
                   sys.exit()
               if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                   audio_manager.play_sound('click')
                   return ("main_menu", None)
               if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                   click_pos = event.pos
                   
                   if selected_stage:
                       # 선택된 스테이지가 있을 때 게임 시작 버튼 처리
                       start_game_button_rect = pygame.Rect(0, 0, scale_x(300), scale_y(80))
                       start_game_button_rect.center = (WIDTH // 2, HEIGHT // 2 + scale_y(120))
                       info_popup_rect = pygame.Rect(0, 0, scale_x(600), scale_y(400))
                       info_popup_rect.center = (WIDTH // 2, HEIGHT // 2)
                       
                       if start_game_button_rect.collidepoint(click_pos):
                           audio_manager.play_sound('click')
                           return ("game_play", selected_stage)
                       elif not info_popup_rect.collidepoint(click_pos):
                           # 팝업 밖을 클릭하면 선택 취소
                           selected_stage = None
                   else:
                       # 스테이지 버튼 클릭 처리
                       for num, data in stage_buttons.items():
                           if (click_pos[0] - data["pos"][0])**2 + (click_pos[1] - data["pos"][1])**2 < data["radius"]**2:
                               audio_manager.play_sound('click')
                               selected_stage = num
                               break
           
           # 호버 효과 업데이트
           mouse_pos = pygame.mouse.get_pos()
           for num, data in stage_buttons.items():
               dist_sq = (mouse_pos[0] - data["pos"][0])**2 + (mouse_pos[1] - data["pos"][1])**2
               target_radius = data["radius"] * 1.1 if dist_sq < data["radius"]**2 and not selected_stage else data["radius"]
               data["current_radius"] += (target_radius - data["current_radius"]) * 0.2
           
           start_button_rect = self.render_manager.render_stage_select(stage_buttons, selected_stage, fonts)
          
           pygame.display.flip()
           self.clock.tick(FPS)

# ======================================================================================
# 메인 실행 부분
# ======================================================================================
def main():
   """메인 함수"""
   game = Game()
   game.run()

if __name__ == '__main__':
   main()