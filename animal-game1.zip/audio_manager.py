# audio_manager.py - 오디오 관리

import pygame
import os
from typing import Dict, Optional

class AudioManager:
    def __init__(self, sound_volume: float = 1.0, music_volume: float = 1.0):
        pygame.mixer.init()
        
        self.sound_volume = sound_volume
        self.music_volume = music_volume
        
        # 사운드 캐시
        self.sounds: Dict[str, pygame.mixer.Sound] = {}
        
        # 기본 사운드 파일 경로
        self.sound_paths = {
            'click': 'assets/Sound/select_002.ogg',
            'jump': 'assets/Sound/confirmation_001.ogg',
            'place': 'assets/Sound/switch_002.ogg',
            'game_over': 'assets/Sound/error_005.ogg',
            'card_slide': 'assets/Sound/card-slide-2.ogg',
            'error': 'assets/Sound/error_008.ogg',
            'tap': 'assets/Sound/tap-a.ogg'
        }
        
        # 사운드 로드
        self.load_sounds()
    
    def load_sounds(self):
        """사운드 파일들을 로드"""
        for name, path in self.sound_paths.items():
            try:
                if os.path.exists(path):
                    sound = pygame.mixer.Sound(path)
                    sound.set_volume(self.sound_volume)
                    self.sounds[name] = sound
                else:
                    print(f"사운드 파일을 찾을 수 없습니다: {path}")
            except pygame.error as e:
                print(f"사운드 로드 오류 ({name}): {e}")
    
    def play_sound(self, sound_name: str):
        """사운드 재생"""
        if sound_name in self.sounds:
            self.sounds[sound_name].play()
        else:
            print(f"사운드를 찾을 수 없습니다: {sound_name}")
    
    def load_music(self, music_path: str):
        """배경음악 로드"""
        try:
            if os.path.exists(music_path):
                pygame.mixer.music.load(music_path)
                pygame.mixer.music.set_volume(self.music_volume)
                return True
            else:
                print(f"음악 파일을 찾을 수 없습니다: {music_path}")
                return False
        except pygame.error as e:
            print(f"음악 로드 오류: {e}")
            return False
    
    def play_music(self, loops: int = -1):
        """배경음악 재생"""
        try:
            pygame.mixer.music.play(loops)
        except pygame.error as e:
            print(f"음악 재생 오류: {e}")
    
    def stop_music(self):
        """배경음악 정지"""
        pygame.mixer.music.stop()
    
    def pause_music(self):
        """배경음악 일시정지"""
        pygame.mixer.music.pause()
    
    def unpause_music(self):
        """배경음악 재개"""
        pygame.mixer.music.unpause()
    
    def set_sound_volume(self, volume: float):
        """사운드 볼륨 설정 (0.0 - 1.0)"""
        self.sound_volume = max(0.0, min(1.0, volume))
        for sound in self.sounds.values():
            sound.set_volume(self.sound_volume)
    
    def set_music_volume(self, volume: float):
        """음악 볼륨 설정 (0.0 - 1.0)"""
        self.music_volume = max(0.0, min(1.0, volume))
        pygame.mixer.music.set_volume(self.music_volume)
    
    def get_sound_volume(self) -> float:
        """현재 사운드 볼륨 반환"""
        return self.sound_volume
    
    def get_music_volume(self) -> float:
        """현재 음악 볼륨 반환"""
        return self.music_volume
    
    def add_sound(self, name: str, path: str):
        """새로운 사운드 추가"""
        try:
            if os.path.exists(path):
                sound = pygame.mixer.Sound(path)
                sound.set_volume(self.sound_volume)
                self.sounds[name] = sound
                return True
            else:
                print(f"사운드 파일을 찾을 수 없습니다: {path}")
                return False
        except pygame.error as e:
            print(f"사운드 추가 오류 ({name}): {e}")
            return False
    
    def remove_sound(self, name: str):
        """사운드 제거"""
        if name in self.sounds:
            del self.sounds[name]
    
    def is_music_playing(self) -> bool:
        """음악이 재생 중인지 확인"""
        return pygame.mixer.music.get_busy()
    
    def fade_out_music(self, time_ms: int):
        """음악 페이드 아웃"""
        pygame.mixer.music.fadeout(time_ms)
    
    def get_available_sounds(self) -> list:
        """사용 가능한 사운드 목록 반환"""
        return list(self.sounds.keys())

# 전역 오디오 매니저 인스턴스
audio_manager = AudioManager()
