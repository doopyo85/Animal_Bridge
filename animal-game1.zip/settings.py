# settings.py

import pygame
import json

# --- 기본 설정 ---
WIDTH, HEIGHT = 1280, 720
FPS = 60

# --- 색상 정의 ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
PLACEHOLDER_COLOR = (170, 170, 170)
ACTIVE_BORDER_COLOR = (70, 130, 180)
RED = (255, 0, 0, 255)
BLUE = (0, 0, 255)
BACKGROUND_COLOR = (50, 50, 60)
YELLOW = (255, 255, 0)

# --- 해상도 목록 ---
RESOLUTIONS = [(1280, 720), (1600, 900), (1920, 1080)]

# --- 충돌 필터링 카테고리 ---
PLAYER_CATEGORY = 0b1
ANIMAL_CATEGORY = 0b10
TERRAIN_CATEGORY = 0b100
CEILING_CATEGORY = 0b1000

# === 추가: 충돌 타입 정의 ===
PLAYER_COLLISION_TYPE = 1
CARNIVORE_HEAD_COLLISION_TYPE = 2
# (다른 객체들은 기본값 0)
# ============================

# --- 육식동물 리스트 ---
CARNIVORES = ["tiger", "lion", "crocodile", "python", "bear"]

# --- JSON 파일에서 동물 블록 데이터 불러오기 ---
try:
    with open('final_animal_blocks.json', 'r') as f:
        ANIMAL_DATA = json.load(f)
except FileNotFoundError:
    print("Error: 'final_animal_blocks.json' 파일을 찾을 수 없습니다.")
    ANIMAL_DATA = {}

# ======================================================================================
# === 추가: 스테이지별 설정 데이터 ===
# ======================================================================================
STAGE_DATA = {
    # 스테이지 1: 기본
    "1": {
        "available_animals": ["sloth", "tiger", "hippo", "lion", "turtle"],
        "terrain": [
            # 시작 발판, 도착 발판, 그리고 그 사이의 다리
            (150, 450, 300, 300), 
            (1130, 450, 300, 300),
            (WIDTH / 2, 585, 980 - 300, 30)
        ]
    },
    # 스테이지 2: 중간에 방해물 추가
    "2": {
        "available_animals": ["sloth", "tiger", "hippo", "lion", "crocodile", "bear", "turtle"],
        "terrain": [
            (150, 450, 300, 300),
            (1130, 450, 300, 300),
            (WIDTH / 2, 585, 980 - 300, 30),
            # 중간에 낮은 방해물
            (WIDTH / 2, 540, 80, 30) 
        ]
    },
    # 스테이지 3: 2개의 끊어진 다리
    "3": {
        "available_animals": ["sloth", "tiger", "hippo", "lion", "crocodile", "bear", "zebra", "python", "flamingo"],
        "terrain": [
            (150, 450, 300, 300),
            (1130, 450, 300, 300),
            # 짧은 다리 두 개와 중간 발판
            (400, 585, 200, 30),
            (WIDTH / 2, 500, 100, 30), # 중간 발판
            (880, 585, 200, 30)
        ]
    },
    # 스테이지 4: 공중 발판 (난폭한 육식동물)
    "4": {
        "available_animals": ["sloth", "tiger", "hippo", "lion", "crocodile", "bear", "zebra", "python", "giraffe", "elephant", "flamingo", "turtle"],
        "violent_carnivores": True,
        "terrain": [
            (150, 550, 300, 200), # 시작 발판을 낮게
            (1130, 550, 300, 200), # 도착 발판을 낮게
            # 중간에 점프해서 건너야 하는 공중 발판들
            (450, 450, 150, 30),
            (WIDTH / 2, 350, 150, 30),
            (830, 450, 150, 30)
        ]
    }
}