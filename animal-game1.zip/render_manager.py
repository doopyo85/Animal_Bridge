# render_manager.py - 렌더링 통합 관리

import pygame
from typing import List, Tuple, Optional
from tilemap_renderer import TileMapManager
from ui_manager import UIManager
from audio_manager import audio_manager

class RenderManager:
    def __init__(self, screen: pygame.Surface):
        self.screen = screen
        self.tilemap_manager = TileMapManager()
        self.ui_manager = UIManager(screen)
        
        # 렌더링 레이어 순서
        self.LAYER_BACKGROUND = 0
        self.LAYER_TERRAIN = 1
        self.LAYER_OBJECTS = 2
        self.LAYER_UI = 3
        self.LAYER_OVERLAY = 4
        
        # 현재 화면 크기
        self.width = screen.get_width()
        self.height = screen.get_height()
    
    def update_screen_size(self, width: int, height: int):
        """화면 크기 업데이트"""
        self.width = width
        self.height = height
        self.ui_manager.screen = self.screen
    
    # ===================================================================================
    # 배경 렌더링
    # ===================================================================================
    def render_background(self, background_type: str = "default"):
        """배경 렌더링"""
        if background_type == "tilemap":
            self.tilemap_manager.render_game_background(self.screen)
        elif background_type == "solid":
            self.screen.fill((135, 206, 235))  # 하늘색
        else:
            self.tilemap_manager.render_game_background(self.screen)
    
    # ===================================================================================
    # 지형 렌더링
    # ===================================================================================
    def render_terrain(self, terrain_rects: List[pygame.Rect]):
        """지형 렌더링"""
        self.tilemap_manager.terrain_renderer.render_terrain(self.screen, terrain_rects)
    
    def render_platform(self, rect: pygame.Rect, platform_type: str = "default"):
        """플랫폼 렌더링"""
        if platform_type == "bridge":
            self.tilemap_manager.terrain_renderer.render_bridge(self.screen, rect, 2.0)
        else:
            self.tilemap_manager.terrain_renderer.render_platform(self.screen, rect, 2.0)
    
    # ===================================================================================
    # UI 렌더링 (메뉴 화면들)
    # ===================================================================================
    def render_start_menu(self, player_name: str, input_active: bool, input_box: pygame.Rect, 
                         next_button_rect: pygame.Rect, fonts: dict):
        """시작 메뉴 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "animal bridge", fonts['title'], 
            (255, 255, 255), (0, 0, 0),
            (self.width // 2, self.height // 2 - 150)
        )
        
        # 프롬프트
        self.ui_manager.draw_centered_text_with_shadow(
            "당신의 이름을 알려주세요", fonts['prompt'],
            (255, 255, 255), (0, 0, 0),
            (self.width // 2, self.height // 2 - 50)
        )
        
        # 입력 상자
        self.ui_manager.draw_text_input(
            input_box, player_name, fonts['input'],
            "클릭해서 이름을 작성하세요", fonts['placeholder'],
            input_active
        )
        
        # 다음 버튼
        self.ui_manager.draw_interactive_button(
            next_button_rect, "다음", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
    
    def render_main_menu(self, player_name: str, button_rects: dict, fonts: dict):
        """메인 메뉴 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "animal bridge", fonts['title'],
            (255, 255, 255), (0, 0, 0),
            (self.width // 2, self.height // 2 - 150)
        )
        
        # 플레이어 이름
        name_surf = fonts['name'].render(player_name, True, (255, 255, 255))
        name_rect = name_surf.get_rect(right=self.width - 40, top=40)
        self.ui_manager.draw_panel(
            name_rect.inflate(20, 10),
            (0, 0, 0, 128), (255, 255, 255), 2, 5
        )
        self.screen.blit(name_surf, name_rect)
        
        # 버튼들
        self.ui_manager.draw_interactive_button(
            button_rects['start'], "게임 시작", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
        self.ui_manager.draw_interactive_button(
            button_rects['desc'], "설명", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
        self.ui_manager.draw_interactive_button(
            button_rects['rank'], "랭킹", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
        
        # 설정 기어
        self.ui_manager.draw_gear(button_rects['settings'], (200, 200, 200))
    
    def render_stage_select(self, stage_buttons: dict, selected_stage: Optional[int], fonts: dict):
        """스테이지 선택 화면 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "스테이지 선택", fonts['title'],
            (255, 255, 255), (0, 0, 0),
            (self.width // 2, 100)
        )
        
        # 스테이지 버튼들
        for num, data in stage_buttons.items():
            is_hovered = self.ui_manager.draw_circular_button(
                data['pos'], data['current_radius'], (200, 200, 200),
                str(num), fonts['stage'], (0, 0, 0), hover_effect=True
            )
            
            # 특별 스테이지 표시
            if num == 4:  # 난폭 스테이지
                feature_pos = (data['pos'][0], data['pos'][1] + data['radius'] + 15)
                feature_surf = fonts['feature'].render("난폭!", True, (255, 0, 0))
                feature_rect = feature_surf.get_rect(center=feature_pos)
                self.screen.blit(feature_surf, feature_rect)
        
        # 선택된 스테이지 정보 팝업
        if selected_stage:
            return self.render_stage_info_popup(selected_stage, fonts)
        return None
    
    def render_stage_info_popup(self, stage_num: int, fonts: dict):
        """스테이지 정보 팝업 렌더링"""
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 180))
        
        # 팝업 패널
        popup_rect = pygame.Rect(0, 0, 600, 400)
        popup_rect.center = (self.width // 2, self.height // 2)
        
        self.ui_manager.draw_panel(
            popup_rect, (230, 230, 230, 220), (0, 0, 0), 3, 15
        )
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            f"스테이지 {stage_num}", fonts['popup_title'],
            (0, 0, 0), (100, 100, 100),
            (popup_rect.centerx, popup_rect.top + 80)
        )
        
        # 정보
        self.ui_manager.draw_centered_text_with_shadow(
            "난이도: 쉬움", fonts['popup_info'],
            (0, 0, 0), (100, 100, 100),
            (popup_rect.centerx, popup_rect.centery - 20)
        )
        
        # 시작 버튼
        start_button_rect = pygame.Rect(0, 0, 300, 80)
        start_button_rect.center = (popup_rect.centerx, popup_rect.bottom - 80)
        
        self.ui_manager.draw_interactive_button(
            start_button_rect, "게임 시작", fonts['popup_info'],
            (255, 255, 255), (240, 240, 240), (100, 100, 100)
        )
        
        return start_button_rect
    
    def render_game_ui(self, ui_animals: list, dragging_animal: Optional[dict], 
                      stats: dict, fonts: dict):
        """게임 플레이 UI 렌더링"""
        # UI 패널
        ui_panel_rect = pygame.Rect(0, self.height - 120, self.width, 120)
        self.ui_manager.draw_game_ui_panel(ui_panel_rect)
        
        # 동물 블록 UI
        for ui_animal in ui_animals:
            if ui_animal.image:
                self.screen.blit(ui_animal.image, ui_animal.rect)
            else:
                pygame.draw.rect(self.screen, ui_animal.icon_color, ui_animal.rect)
                text = fonts['small'].render(ui_animal.name, True, (0, 0, 0))
                text_rect = text.get_rect(center=ui_animal.rect.center)
                self.screen.blit(text, text_rect)
        
        # 드래그 중인 동물
        if dragging_animal:
            self.render_dragging_animal(dragging_animal)
        
        # 통계 정보
        self.render_game_stats(stats, fonts)
    
    def render_dragging_animal(self, dragging_animal: dict):
        """드래그 중인 동물 렌더링"""
        mouse_x, mouse_y = pygame.mouse.get_pos()
        
        # 드롭 존 표시
        drop_zone = pygame.Rect(300, 30, 680, 130)
        pygame.draw.rect(self.screen, (0, 255, 0, 50), drop_zone, 2)
        
        # 드래그 중인 동물 이미지
        if dragging_animal.get("image"):
            rotated_image = pygame.transform.rotate(
                dragging_animal["image"], 
                -dragging_animal.get("angle_degrees", 0)
            )
            img_rect = rotated_image.get_rect(center=(mouse_x, mouse_y))
            self.screen.blit(rotated_image, img_rect)
        else:
            # 기본 사각형
            rect = pygame.Rect(mouse_x - 30, mouse_y - 30, 60, 60)
            pygame.draw.rect(self.screen, (255, 0, 255), rect, 5)
    
    def render_game_stats(self, stats: dict, fonts: dict):
        """게임 통계 정보 렌더링"""
        self.ui_manager.draw_stats_display(
            stats, (10, 10), fonts['small'], 
            (255, 255, 255), (0, 0, 0, 128)
        )
    
    def render_ending_scene(self, stage_num: int, stats: dict, fonts: dict, next_button_rect: pygame.Rect):
        """엔딩 화면 렌더링"""
        # 오버레이
        self.ui_manager.draw_overlay((240, 240, 240, 220))
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            f"스테이지 {stage_num} 클리어", fonts['title'],
            (0, 0, 0), (100, 100, 100),
            (self.width // 2, self.height // 2 - 200)
        )
        
        # 통계
        y_pos = self.height // 2 - 50
        for key, value in stats.items():
            text = f"{key}: {value}"
            self.ui_manager.draw_centered_text_with_shadow(
                text, fonts['stats'], (0, 0, 0), (100, 100, 100),
                (self.width // 2, y_pos)
            )
            y_pos += 100
        
        # 다음 버튼
        self.ui_manager.draw_interactive_button(
            next_button_rect, "다음", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
    
    def render_game_over_screen(self, fonts: dict, menu_button_rect: pygame.Rect):
        """게임 오버 화면 렌더링"""
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 180))
        
        # GAME OVER 텍스트
        self.ui_manager.draw_centered_text_with_shadow(
            "GAME OVER", fonts['title'], (255, 0, 0), (50, 0, 0),
            (self.width // 2, self.height // 2 - 50)
        )
        
        # 메뉴 버튼
        self.ui_manager.draw_interactive_button(
            menu_button_rect, "메인 메뉴로", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
    
    def render_description_screen(self, text_surface: pygame.Surface, view_rect: pygame.Rect, 
                                scroll_y: int, fonts: dict, back_button_rect: pygame.Rect):
        """설명 화면 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 180))
        
        # 메인 패널
        panel_rect = pygame.Rect(0, 0, self.width - 200, self.height - 150)
        panel_rect.center = (self.width // 2, self.height // 2)
        
        self.ui_manager.draw_panel(
            panel_rect, (40, 40, 50, 230), (255, 255, 255), 3, 15
        )
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "게임 설명", fonts['title'], (255, 255, 255), (0, 0, 0),
            (panel_rect.centerx, panel_rect.top + 60)
        )
        
        # 스크롤 가능한 텍스트
        text_area_pos = (panel_rect.left + 50, panel_rect.top + 120)
        self.ui_manager.draw_scrollable_text(text_surface, view_rect, scroll_y)
        
        # 뒤로 가기 버튼
        self.ui_manager.draw_interactive_button(
            back_button_rect, "뒤로 가기", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
    
    def render_settings_screen(self, current_res_index: int, temp_volume: float, 
                             fonts: dict, ui_rects: dict, resolution_dropdown_open: bool):
        """설정 화면 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 150))
        
        # 설정 패널
        settings_rect = ui_rects['settings_bg']
        self.ui_manager.draw_panel(
            settings_rect, (230, 230, 230, 220), (0, 0, 0), 3, 15
        )
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "설정", fonts['title'], (0, 0, 0), (100, 100, 100),
            (settings_rect.centerx, settings_rect.top + 70)
        )
        
        # 해상도 설정
        res_text_surf = fonts['option'].render("화면 크기", True, (0, 0, 0))
        self.screen.blit(res_text_surf, ui_rects['res_text'])
        
        from settings import RESOLUTIONS
        resolution_text = f"{RESOLUTIONS[current_res_index][0]}x{RESOLUTIONS[current_res_index][1]}"
        option_rects = self.ui_manager.draw_dropdown_menu(
            ui_rects['screen_size_button'], 
            [f"{res[0]}x{res[1]}" for res in RESOLUTIONS],
            current_res_index, fonts['option'], resolution_dropdown_open
        )
        
        # 사운드 설정
        sound_text_surf = fonts['option'].render("사운드", True, (0, 0, 0))
        self.screen.blit(sound_text_surf, ui_rects['sound_text'])
        
        self.ui_manager.draw_slider(
            ui_rects['sound_slider'], ui_rects['sound_handle'],
            (255, 255, 255), (150, 150, 150), (0, 0, 0)
        )
        
        # 뒤로 가기 버튼
        self.ui_manager.draw_interactive_button(
            ui_rects['back_button'], "뒤로 가기", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
        
        return option_rects
    
    def render_ranking_screen(self, current_stage: int, ranking_data: list, 
                            fonts: dict, ui_rects: dict):
        """랭킹 화면 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 150))
        
        # 제목과 화살표
        title_text = f"랭킹 (스테이지 {current_stage})"
        self.ui_manager.draw_centered_text_with_shadow(
            title_text, fonts['title'], (255, 255, 255), (0, 0, 0),
            (self.width // 2, 120)
        )
        
        # 화살표 버튼들
        mouse_pos = pygame.mouse.get_pos()
        left_color = (255, 255, 255) if ui_rects['left_arrow'].collidepoint(mouse_pos) else (200, 200, 200)
        right_color = (255, 255, 255) if ui_rects['right_arrow'].collidepoint(mouse_pos) else (200, 200, 200)
        
        left_surf = fonts['arrow'].render("<", True, left_color)
        right_surf = fonts['arrow'].render(">", True, right_color)
        self.screen.blit(left_surf, left_surf.get_rect(center=ui_rects['left_arrow'].center))
        self.screen.blit(right_surf, right_surf.get_rect(center=ui_rects['right_arrow'].center))
        
        # 랭킹 데이터
        start_y = 220
        if not ranking_data:
            no_data_surf = fonts['rank'].render("기록이 없습니다", True, (200, 200, 200))
            self.screen.blit(no_data_surf, no_data_surf.get_rect(center=(self.width // 2, start_y + 100)))
        else:
            for i, record in enumerate(ranking_data):
                entry_rect = pygame.Rect(0, 0, self.width - 300, 70)
                entry_rect.center = (self.width // 2, start_y + i * 80)
                
                self.ui_manager.draw_panel(
                    entry_rect, (240, 240, 240, 200), (0, 0, 0), 2, 10
                )
                
                # 순위
                rank_surf = fonts['rank'].render(f"#{i+1}", True, (0, 0, 0))
                rank_rect = rank_surf.get_rect(center=(entry_rect.left + 50, entry_rect.centery))
                self.screen.blit(rank_surf, rank_rect)
                
                # 이름
                name_surf = fonts['rank'].render(record["name"], True, (0, 0, 0))
                name_rect = name_surf.get_rect(midleft=(entry_rect.left + 110, entry_rect.centery))
                self.screen.blit(name_surf, name_rect)
                
                # 시간
                time_surf = fonts['rank'].render(f"{record['time']:.2f} 초", True, (50, 50, 50))
                time_rect = time_surf.get_rect(center=(entry_rect.centerx, entry_rect.centery))
                self.screen.blit(time_surf, time_rect)
                
                # 사용한 블록
                blocks_surf = fonts['rank'].render(f"사용: {record['blocks']}개", True, (50, 50, 50))
                blocks_rect = blocks_surf.get_rect(midright=(entry_rect.right - 160, entry_rect.centery))
                self.screen.blit(blocks_surf, blocks_rect)
                
                # 먹힌 블록
                eaten_count = record.get("eaten", 0)
                eaten_surf = fonts['rank'].render(f"먹힘: {eaten_count}개", True, (50, 50, 50))
                eaten_rect = eaten_surf.get_rect(midright=(entry_rect.right - 30, entry_rect.centery))
                self.screen.blit(eaten_surf, eaten_rect)
        
        # 뒤로 가기 버튼
        self.ui_manager.draw_interactive_button(
            ui_rects['back_button'], "뒤로 가기", fonts['button'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
        
    def render_description(self, back_button_rect, fonts):
        """게임 설명 화면 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 180))
        
        # 메인 패널
        panel_rect = pygame.Rect(0, 0, self.width - 200, self.height - 150)
        panel_rect.center = (self.width // 2, self.height // 2)
        
        self.ui_manager.draw_panel(
            panel_rect, (40, 40, 50, 230), (255, 255, 255), 3, 15
        )
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "게임 설명", fonts['desc'], (255, 255, 255), (0, 0, 0),
            (panel_rect.centerx, panel_rect.top + 60)
        )
        
        # 설명 텍스트
        description_lines = [
            "동물 블록을 사용해서 다리를 만들어 목적지에 도달하세요!",
            "", 
            "조작법:",
            "- A, D 키: 좌우 이동",
            "- SPACE 키: 점프",
            "- 마우스: 동물 블록 드래그&드롭",
            "- R 키: 드래그 중 블록 회전",
            "- TAB 키: 메뉴로 돌아가기",
            "",
            "목표: 빨간 깃발에 도달하세요!",
            "육식동물들이 다른 동물들을 잡아먹을 수 있습니다."
        ]
        
        y_pos = panel_rect.top + 120
        for line in description_lines:
            if line:
                text_surf = fonts['desc'].render(line, True, (255, 255, 255))
                text_rect = text_surf.get_rect(centerx=panel_rect.centerx, y=y_pos)
                self.screen.blit(text_surf, text_rect)
            y_pos += 40
        
        # 뒤로 가기 버튼
        self.ui_manager.draw_interactive_button(
            back_button_rect, "뒤로 가기", fonts['desc'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
        
    def render_settings(self, back_button_rect, fonts):
        """설정 화면 렌더링"""
        # 배경
        self.render_background("tilemap")
        
        # 오버레이
        self.ui_manager.draw_overlay((0, 0, 0, 150))
        
        # 설정 패널
        settings_rect = pygame.Rect(0, 0, self.width - 400, self.height - 200)
        settings_rect.center = (self.width // 2, self.height // 2)
        
        self.ui_manager.draw_panel(
            settings_rect, (230, 230, 230, 220), (0, 0, 0), 3, 15
        )
        
        # 제목
        self.ui_manager.draw_centered_text_with_shadow(
            "설정", fonts['settings'], (0, 0, 0), (100, 100, 100),
            (settings_rect.centerx, settings_rect.top + 70)
        )
        
        # 설정 항목들
        y_pos = settings_rect.top + 150
        
        # 화면 크기 설정
        res_text = fonts['settings'].render("화면 크기: 1280x720 (기본)", True, (0, 0, 0))
        res_rect = res_text.get_rect(centerx=settings_rect.centerx, y=y_pos)
        self.screen.blit(res_text, res_rect)
        y_pos += 80
        
        # 사운드 설정
        sound_text = fonts['settings'].render("사운드 볼륨: 100%", True, (0, 0, 0))
        sound_rect = sound_text.get_rect(centerx=settings_rect.centerx, y=y_pos)
        self.screen.blit(sound_text, sound_rect)
        y_pos += 80
        
        # 정보
        info_text = fonts['settings'].render("(설정 기능은 개발 중입니다)", True, (100, 100, 100))
        info_rect = info_text.get_rect(centerx=settings_rect.centerx, y=y_pos)
        self.screen.blit(info_text, info_rect)
        
        # 뒤로 가기 버튼
        self.ui_manager.draw_interactive_button(
            back_button_rect, "뒤로 가기", fonts['settings'],
            (220, 220, 220), (255, 255, 255), (100, 100, 100)
        )
