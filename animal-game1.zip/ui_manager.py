# ui_manager.py - UI 렌더링 및 인터페이스 관리

import pygame
import math
from settings import *

class UIManager:
    def __init__(self, screen):
        self.screen = screen
        self.font_cache = {}
        
    def get_font(self, font_name, size, bold=False, italic=False):
        """폰트 캐싱"""
        key = (font_name, size, bold, italic)
        if key not in self.font_cache:
            self.font_cache[key] = pygame.font.SysFont(font_name, size, bold=bold, italic=italic)
        return self.font_cache[key]
    
    def draw_gear(self, rect, color):
        """기어 모양 그리기"""
        center = rect.center
        outer_radius = rect.width / 2 * 0.9
        inner_radius = outer_radius * 0.7
        hole_radius = outer_radius * 0.4
        num_teeth = 8
        points = []
        angle_step = 360 / num_teeth
        
        for i in range(num_teeth):
            angle1 = math.radians(i * angle_step - angle_step / 4)
            angle2 = math.radians(i * angle_step + angle_step / 4)
            points.append((center[0] + inner_radius * math.cos(angle1), center[1] + inner_radius * math.sin(angle1)))
            points.append((center[0] + outer_radius * math.cos(angle1), center[1] + outer_radius * math.sin(angle1)))
            points.append((center[0] + outer_radius * math.cos(angle2), center[1] + outer_radius * math.sin(angle2)))
            points.append((center[0] + inner_radius * math.cos(angle2), center[1] + inner_radius * math.sin(angle2)))
        
        for i in range(0, len(points), 4):
            pygame.draw.polygon(self.screen, color, points[i:i+4])
        pygame.draw.circle(self.screen, color, center, inner_radius)
        pygame.draw.circle(self.screen, WHITE, center, hole_radius)
    
    def draw_interactive_button(self, rect, text, font, base_color, hover_color, shadow_color):
        """인터랙티브 버튼 그리기"""
        mouse_pos = pygame.mouse.get_pos()
        is_hovered = rect.collidepoint(mouse_pos)
        
        # 그림자
        shadow_rect = rect.move(5, 5)
        pygame.draw.rect(self.screen, shadow_color, shadow_rect, border_radius=12)
        
        # 버튼 배경
        button_color = hover_color if is_hovered else base_color
        pygame.draw.rect(self.screen, button_color, rect, border_radius=10)
        pygame.draw.rect(self.screen, BLACK, rect, 2, border_radius=10)
        
        # 텍스트
        text_surf = font.render(text, True, BLACK)
        text_rect = text_surf.get_rect(center=rect.center)
        self.screen.blit(text_surf, text_rect)
        
        return is_hovered
    
    def draw_text_input(self, rect, text, font, placeholder_text, placeholder_font, is_active):
        """텍스트 입력 상자 그리기"""
        # 배경
        pygame.draw.rect(self.screen, GRAY, rect, 0, 5)
        
        # 텍스트 또는 플레이스홀더
        if not text:
            placeholder_surf = placeholder_font.render(placeholder_text, True, PLACEHOLDER_COLOR)
            self.screen.blit(placeholder_surf, placeholder_surf.get_rect(midleft=(rect.x + 15, rect.centery)))
        else:
            text_surf = font.render(text, True, BLACK)
            self.screen.blit(text_surf, text_surf.get_rect(midleft=(rect.x + 15, rect.centery)))
        
        # 테두리
        border_color = ACTIVE_BORDER_COLOR if is_active else GRAY
        pygame.draw.rect(self.screen, border_color, rect, 3, 5)
    
    def draw_panel(self, rect, background_color, border_color, border_width=3, border_radius=15):
        """패널 그리기"""
        pygame.draw.rect(self.screen, background_color, rect, 0, border_radius)
        pygame.draw.rect(self.screen, border_color, rect, border_width, border_radius)
    
    def draw_overlay(self, color_alpha):
        """화면 오버레이 그리기"""
        overlay = pygame.Surface((self.screen.get_width(), self.screen.get_height()), pygame.SRCALPHA)
        overlay.fill(color_alpha)
        self.screen.blit(overlay, (0, 0))
    
    def draw_text_with_shadow(self, text, font, text_color, shadow_color, position, shadow_offset=(3, 3)):
        """그림자가 있는 텍스트 그리기"""
        shadow_surf = font.render(text, True, shadow_color)
        text_surf = font.render(text, True, text_color)
        
        shadow_pos = (position[0] + shadow_offset[0], position[1] + shadow_offset[1])
        self.screen.blit(shadow_surf, shadow_pos)
        self.screen.blit(text_surf, position)
    
    def draw_centered_text_with_shadow(self, text, font, text_color, shadow_color, center_pos, shadow_offset=(3, 3)):
        """중앙 정렬된 그림자 텍스트 그리기"""
        text_surf = font.render(text, True, text_color)
        text_rect = text_surf.get_rect(center=center_pos)
        
        shadow_surf = font.render(text, True, shadow_color)
        shadow_rect = shadow_surf.get_rect(center=(center_pos[0] + shadow_offset[0], center_pos[1] + shadow_offset[1]))
        
        self.screen.blit(shadow_surf, shadow_rect)
        self.screen.blit(text_surf, text_rect)
    
    def draw_slider(self, slider_rect, handle_rect, handle_color, track_color, border_color):
        """슬라이더 그리기"""
        # 트랙
        pygame.draw.rect(self.screen, track_color, slider_rect, 0, 8)
        
        # 핸들
        pygame.draw.rect(self.screen, handle_color, handle_rect, 0, 5)
        pygame.draw.rect(self.screen, border_color, handle_rect, 2, 5)
    
    def draw_progress_bar(self, rect, progress, bg_color, fill_color, border_color):
        """진행률 표시줄 그리기"""
        # 배경
        pygame.draw.rect(self.screen, bg_color, rect, 0, 5)
        
        # 진행률
        if progress > 0:
            fill_width = int(rect.width * progress)
            fill_rect = pygame.Rect(rect.x, rect.y, fill_width, rect.height)
            pygame.draw.rect(self.screen, fill_color, fill_rect, 0, 5)
        
        # 테두리
        pygame.draw.rect(self.screen, border_color, rect, 2, 5)
    
    def draw_circular_button(self, center, radius, color, text, font, text_color, hover_effect=True):
        """원형 버튼 그리기"""
        mouse_pos = pygame.mouse.get_pos()
        distance = math.sqrt((mouse_pos[0] - center[0])**2 + (mouse_pos[1] - center[1])**2)
        is_hovered = distance < radius
        
        # 호버 효과
        if hover_effect and is_hovered:
            draw_radius = int(radius * 1.1)
            shadow_color = (0, 0, 0, 100)
            pygame.draw.circle(self.screen, shadow_color, (center[0] + 4, center[1] + 4), draw_radius)
        else:
            draw_radius = radius
        
        # 버튼
        pygame.draw.circle(self.screen, BLACK, center, draw_radius + 4)  # 그림자
        pygame.draw.circle(self.screen, color, center, draw_radius)
        
        # 텍스트
        text_surf = font.render(text, True, text_color)
        text_rect = text_surf.get_rect(center=center)
        self.screen.blit(text_surf, text_rect)
        
        return is_hovered
    
    def draw_notification(self, text, font, bg_color, text_color, position, padding=10):
        """알림 메시지 그리기"""
        text_surf = font.render(text, True, text_color)
        text_rect = text_surf.get_rect()
        
        # 배경 박스
        box_rect = text_rect.inflate(padding * 2, padding * 2)
        box_rect.center = position
        
        pygame.draw.rect(self.screen, bg_color, box_rect, 0, 10)
        pygame.draw.rect(self.screen, BLACK, box_rect, 2, 10)
        
        # 텍스트
        text_rect.center = position
        self.screen.blit(text_surf, text_rect)
    
    def draw_game_ui_panel(self, rect, alpha=180):
        """게임 UI 패널 그리기"""
        ui_panel = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        ui_panel.fill((200, 200, 200, alpha))
        self.screen.blit(ui_panel, rect.topleft)
    
    def draw_stats_display(self, stats_dict, position, font, text_color=WHITE, bg_color=(0, 0, 0, 128)):
        """통계 정보 표시"""
        y_offset = 0
        line_height = font.get_height() + 5
        
        for key, value in stats_dict.items():
            text = f"{key}: {value}"
            text_surf = font.render(text, True, text_color)
            
            # 배경
            bg_rect = text_surf.get_rect()
            bg_rect.topleft = (position[0], position[1] + y_offset)
            bg_rect.inflate_ip(10, 2)
            
            bg_surface = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
            bg_surface.fill(bg_color)
            self.screen.blit(bg_surface, bg_rect)
            
            # 텍스트
            self.screen.blit(text_surf, (position[0] + 5, position[1] + y_offset))
            y_offset += line_height
    
    def draw_dropdown_menu(self, button_rect, options, selected_index, font, is_open):
        """드롭다운 메뉴 그리기"""
        # 메인 버튼
        selected_text = options[selected_index] if selected_index < len(options) else "Select..."
        self.draw_interactive_button(
            button_rect, selected_text, font, 
            WHITE, (240, 240, 240), (100, 100, 100)
        )
        
        # 드롭다운 옵션들
        if is_open:
            option_rects = []
            for i, option in enumerate(options):
                option_rect = pygame.Rect(button_rect)
                option_rect.y += (i + 1) * (button_rect.height + 5)
                option_rects.append(option_rect)
                
                self.draw_interactive_button(
                    option_rect, option, font,
                    WHITE, (240, 240, 240), (100, 100, 100)
                )
            
            return option_rects
        return []
    
    def draw_scrollable_text(self, text_surface, view_rect, scroll_y):
        """스크롤 가능한 텍스트 그리기"""
        self.screen.blit(text_surface, view_rect.topleft, 
                        (0, scroll_y, view_rect.width, view_rect.height))
    
    def create_text_surface(self, lines, line_spacing=5):
        """여러 줄 텍스트 서피스 생성"""
        if not lines:
            return pygame.Surface((1, 1), pygame.SRCALPHA)
        
        total_height = sum(font.get_height() for text, font, color in lines) + (len(lines) - 1) * line_spacing
        max_width = max(font.size(text)[0] for text, font, color in lines)
        
        surface = pygame.Surface((max_width, total_height), pygame.SRCALPHA)
        
        y_offset = 0
        for text, font, color in lines:
            text_surf = font.render(text, True, color)
            surface.blit(text_surf, (0, y_offset))
            y_offset += font.get_height() + line_spacing
        
        return surface
